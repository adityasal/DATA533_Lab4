from setuptools import setup, find_packages

setup(
name='graphsTrees',
version='0.1',
packages=find_packages(exclude=['tests*']),
license='MIT',
description='An assignment package for graph and tree data structures',
url='https://github.com/adityasal/DATA533_Lab4',
author='Eric Baxter, Aditya Saluja',
author_email='ebaxter1@hotmail.ca'
)