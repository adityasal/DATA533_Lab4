class vertexError(Exception):
    pass

class edgeError(Exception):
    pass

class weightError(Exception):
    pass
