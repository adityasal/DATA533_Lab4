class NodeError(Exception):
    pass

class NodeKeyError(Exception):
    pass 
